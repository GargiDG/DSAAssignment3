
import java.util.ArrayList;
import java.util.List;

public class DSA3Q7 {
	public static List<String> findMissingRanges(int[] nums, int lower, int upper) {
        List<String> ranges = new ArrayList<>();

        int next = lower;

        for (int num : nums) {
            if (num > next) {
                ranges.add(formatRange(next, num - 1));
            }

            next = num + 1;
        }

        if (next <= upper) {
            ranges.add(formatRange(next, upper));
        }

        return ranges;
    }

    private static String formatRange(int start, int end) {
       
            return  "[" +start + "," + end+"]";
      
    }
	public static void main(String[] args) {
		int[] nums = {0, 1, 3, 50, 75};
        int lower = 0;
        int upper = 99;

        List<String> result = findMissingRanges(nums, lower, upper);

        System.out.println("Output: " + result);

	}

}



