
public class DSA3Q6 {
	   public static int singleNumber(int[] nums) {
	        int result = 0;

	        // XOR all elements in the array
	        for (int num : nums) {
	            result ^= num;
	        }

	        return result;
	    }
	public static void main(String[] args) {
		  int[] nums = {2, 2, 1};
	        int result = singleNumber(nums);
	        System.out.println("Output: " + result);
	}

}


