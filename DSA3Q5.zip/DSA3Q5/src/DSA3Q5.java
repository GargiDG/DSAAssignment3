
public class DSA3Q5 {
	public static int[] plusOne(int[] digits) {
        int n = digits.length;

        // Start from the rightmost digit
        for (int i = n - 1; i >= 0; i--) {
            // Increment the current digit by 1
            digits[i]++;

            // If the digit becomes 10, set it to 0 and carry the 1 to the next digit
            if (digits[i] == 10) {
                digits[i] = 0;
            } else {
                // No carry, so we're done
                return digits;
            }
        }

        // If all digits became 0 and we still have a carry, create a new array with a larger size
        int[] result = new int[n + 1];
        result[0] = 1;
        return result;
    }
	public static void main(String[] args) {
		 int[] digits = {1, 2, 3};
	        int[] result = plusOne(digits);
	        System.out.print("Output: ");
	        for (int digit : result) {
	            System.out.print(digit + " ");
	        }
	}

}


